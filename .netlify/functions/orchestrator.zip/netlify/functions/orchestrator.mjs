
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/orchestrator.mts
import { createLLMProvider } from "@AiDigital-com/design-system/server";

// netlify/functions/_shared/auth.ts
import { verifyToken, createClerkClient } from "@clerk/backend";
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/_shared/supabase.ts
import { createClient } from "@supabase/supabase-js";
var supabaseUrl = process.env.SUPABASE_URL || "https://njwzbptrhgznozpndcxf.supabase.co";
var supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function getSupabase() {
  if (!supabaseKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY not configured");
  return createClient(supabaseUrl, supabaseKey);
}
var supabase = new Proxy({}, {
  get(_, prop) {
    return getSupabase()[prop];
  }
});

// netlify/functions/_shared/logger.ts
import { createLogger } from "@AiDigital-com/design-system/logger";
var log = createLogger(supabase, "competitor-campaign-review");

// netlify/functions/_shared/auth.ts
var EMBED_APP_NAME = "competitor-campaign-review";
async function requireAuthOrEmbed(req) {
  const embedToken = req.headers.get("X-Embed-Token");
  if (embedToken) {
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) throw new Error("Supabase not configured");
    const sb = createClient2(url, key);
    const { data } = await sb.rpc("validate_embed_token", {
      p_token: embedToken,
      p_app: EMBED_APP_NAME,
      p_origin: req.headers.get("Origin") || null
    });
    if (!data?.valid) throw new Error("Invalid embed token");
    return { userId: `embed:${data.org_id || "anonymous"}`, email: null, isEmbed: true };
  }
  const apiKey = req.headers.get("X-API-Key");
  if (apiKey?.startsWith("aidl_")) {
    return { userId: `api:${apiKey.substring(5, 13)}`, email: null };
  }
  return requireAuth(req);
}
async function requireAuth(req) {
  const secretKey = process.env.CLERK_SECRET_KEY;
  if (!secretKey) throw new Error("CLERK_SECRET_KEY not configured");
  const authHeader = req.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "").trim();
  if (!token) {
    log.warn("auth.failure", { function_name: "auth", message: "Unauthorized", meta: { endpoint: req.url } });
    throw new Error("Unauthorized");
  }
  const payload = await verifyToken(token, { secretKey });
  const userId = payload.sub;
  let email = null;
  try {
    const clerk = createClerkClient({ secretKey });
    const user = await clerk.users.getUser(userId);
    const primary = user.emailAddresses.find((e) => e.id === user.primaryEmailAddressId);
    email = primary?.emailAddress ?? null;
  } catch {
  }
  return { userId, email };
}

// netlify/functions/orchestrator.mts
import { createClient as createClient3 } from "@supabase/supabase-js";
var APP_NAME = "competitor-campaign-review";
var DISPATCH_TOOL = {
  name: "dispatch_task",
  description: "Dispatch competitor analysis once the brand domain is confirmed.",
  parameters: {
    type: "object",
    properties: {
      brand_domain: {
        type: "string",
        description: 'The target brand domain to analyze (e.g. "nike.com").'
      },
      source: {
        type: "string",
        enum: ["url", "image"],
        description: 'How the domain was provided \u2014 "url" if typed, "image" if from uploaded creative.'
      }
    },
    required: ["brand_domain", "source"]
  }
};
var BASE_SYSTEM_PROMPT = `You are the intake coordinator for the Competitor Campaign Review tool.
Your goal: identify the target brand domain and call dispatch_task.

Two input modes:
1. URL/domain typed by user: Extract the domain (e.g. "nike.com" from "https://www.nike.com/us/t/air-max"). Call dispatch_task immediately \u2014 no confirmation needed.
2. Image upload: The system will provide image analysis results. Confirm the brand with the user, suggest the domain, and dispatch once confirmed (a simple "yes" or "looks good" is sufficient).

Keep responses brief \u2014 1-2 sentences. Do not explain what you're doing.`;
var orchestrator_default = async (req) => {
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }
  let authEmail = null;
  let authUserId = null;
  try {
    const auth = await requireAuthOrEmbed(req);
    authEmail = auth.email;
    authUserId = auth.userId;
  } catch {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!process.env.GEMINI_API_KEY) {
    return Response.json({ error: "GEMINI_API_KEY not configured" }, { status: 500 });
  }
  const body = await req.json();
  const { messages = [], userId, imageBase64, imageMimeType } = body;
  const uid = userId || authUserId;
  const supabase2 = createClient3(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
  const llmFast = createLLMProvider("gemini", process.env.GEMINI_API_KEY, "fast", { supabase: supabase2 });
  let systemPrompt = BASE_SYSTEM_PROMPT;
  if (imageBase64 && imageMimeType) {
    try {
      const llmAnalysis = createLLMProvider("gemini", process.env.GEMINI_API_KEY, "analysis", { supabase: supabase2 });
      const rawBase64 = imageBase64.replace(/^data:[^;]+;base64,/, "");
      const analysis = await llmAnalysis.generateContent({
        prompt: 'Analyze this advertisement or brand image. Return JSON only, no markdown: {"brandName": "...", "suggestedDomain": "...", "category": "..."}',
        userParts: [{ inlineData: { data: rawBase64, mimeType: imageMimeType } }],
        app: `${APP_NAME}:image-analysis`,
        userId: uid,
        jsonMode: true
      });
      let parsed = {};
      try {
        parsed = JSON.parse(analysis.text);
      } catch {
        const match = analysis.text.match(/\{[\s\S]*\}/);
        if (match) parsed = JSON.parse(match[0]);
      }
      if (parsed.brandName && parsed.suggestedDomain) {
        systemPrompt += `

Image analysis: The uploaded creative is from brand "${parsed.brandName}" (${parsed.category || "unknown category"}). Suggested domain: "${parsed.suggestedDomain}". Your first response must confirm this with the user: "This looks like a campaign from [brand]. Should I use [domain] for the competitor analysis?" Then wait for confirmation before dispatching.`;
      }
    } catch (err) {
      console.warn("Image analysis failed, falling back to text intake:", err);
      systemPrompt += `

The user uploaded a campaign image. Ask them: "I've received your image. What brand or website domain should I analyze for competitor intelligence?"`;
    }
  }
  const chatMessages = messages.map((m) => ({
    role: m.role,
    content: m.content
  }));
  const encoder = new TextEncoder();
  const readable = new ReadableStream({
    async start(controller) {
      const emit = (data) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}

`));
      };
      const keepAliveInterval = setInterval(() => {
        controller.enqueue(encoder.encode(": keepalive\n\n"));
      }, 15e3);
      log.info("orchestrator.start", {
        function_name: "orchestrator",
        user_id: uid,
        user_email: authEmail,
        ai_provider: llmFast.provider,
        ai_model: llmFast.model,
        meta: { messageCount: messages?.length, hasImage: !!imageBase64 }
      });
      const startTime = Date.now();
      try {
        const result = await llmFast.streamChat({
          system: systemPrompt,
          messages: chatMessages,
          tools: [DISPATCH_TOOL],
          callbacks: {
            onText: (text) => emit({ type: "text_delta", text }),
            onToolCalls: (calls) => {
              for (const call of calls) {
                if (call.name === "dispatch_task") {
                  emit({ type: "competitor_dispatch", intakeSummary: call.args });
                }
              }
            }
          },
          app: `${APP_NAME}:orchestrator`,
          userId: uid
        });
        log.info("orchestrator.complete", {
          function_name: "orchestrator",
          user_id: uid,
          user_email: authEmail,
          duration_ms: Date.now() - startTime,
          ai_provider: llmFast.provider,
          ai_model: llmFast.model,
          ai_input_tokens: result.usage.inputTokens,
          ai_output_tokens: result.usage.outputTokens,
          ai_total_tokens: result.usage.totalTokens,
          ai_thinking_tokens: result.usage.thinkingTokens
        });
        emit({ type: "done" });
      } catch (err) {
        console.error("Orchestrator error:", err);
        log.error("orchestrator.error", {
          function_name: "orchestrator",
          user_id: uid,
          user_email: authEmail,
          error: err,
          error_category: "ai_api",
          duration_ms: Date.now() - startTime
        });
        emit({ type: "error", message: String(err) });
      } finally {
        clearInterval(keepAliveInterval);
        controller.close();
      }
    }
  });
  return new Response(readable, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive"
    }
  });
};
export {
  orchestrator_default as default
};
