
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/ccr-pipeline-background.mts
import { createLLMProvider } from "@AiDigital-com/design-system/server";
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/_shared/dataforseo.ts
var BASE_URL = "https://api.dataforseo.com";
var US_LOCATION_CODE = 2840;
async function getCompetitorDomains(domain) {
  const auth = process.env.DATAFORSEO_AUTH;
  if (!auth) throw new Error("DATAFORSEO_AUTH not configured");
  const res = await fetch(`${BASE_URL}/v3/dataforseo_labs/google/competitors_domain/live`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify([
      {
        target: domain,
        language_code: "en",
        location_code: US_LOCATION_CODE,
        limit: 15,
        filters: [["intersections", ">=", 5]]
      }
    ])
  });
  if (!res.ok) {
    throw new Error(`DataForSeo API error: ${res.status} ${res.statusText}`);
  }
  const json = await res.json();
  const task = json?.tasks?.[0];
  if (task?.status_code !== 2e4) {
    console.warn("DataForSeo task error:", task?.status_message);
    return [];
  }
  const items = task?.result?.[0]?.items ?? [];
  return items.map((item) => item.domain).filter(Boolean).slice(0, 15);
}

// netlify/functions/_shared/bigquery.ts
import { BigQuery } from "@google-cloud/bigquery";
import { createClient as createSupabase } from "@supabase/supabase-js";
function createBqClient() {
  const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
  return new BigQuery({
    projectId: process.env.GCP_PROJECT_ID,
    credentials
  });
}
function tableRef() {
  const project = process.env.GCP_PROJECT_ID;
  const dataset = process.env.ADCLARITY_DATASET || "adclarity_competitor_analysis";
  const table = process.env.ADCLARITY_TABLE_NAME || "adclarity_aws_monthly_test_2026";
  return `\`${project}.${dataset}.${table}\``;
}
async function getAdClarityData(domains) {
  try {
    const result = await queryMode(domains);
    if (result.length > 0) return result;
  } catch (err) {
    const msg = err?.message || "";
    if (!msg.includes("bigquery.jobs.create") && !msg.includes("Access Denied")) throw err;
    console.log("[AdClarity] Query mode blocked \u2014 trying Supabase training data");
  }
  try {
    const result = await supabaseTrainingMode(domains);
    if (result.length > 0) {
      console.log(`[AdClarity] Supabase training data: ${result.length} domains`);
      return result;
    }
  } catch (err) {
    console.log("[AdClarity] Supabase training mode failed:", err.message);
  }
  console.log("[AdClarity] Falling back to BQ table scan");
  return trainingMode(domains);
}
async function queryMode(domains) {
  const bq = createBqClient();
  const query = `
    WITH deduped AS (
      SELECT
        LOWER(advertiser_domain) AS domain,
        LOWER(publisher_domain)  AS publisher,
        channel_name             AS channel,
        CAST(creative_id AS STRING) AS creative_id,
        creative_url_supplier    AS creative_url,
        creative_mime_type       AS creative_mime_type,
        creative_first_seen_date AS creative_first_seen,
        MAX(impressions)         AS impressions,
        MAX(spend)               AS spend
      FROM ${tableRef()}
      WHERE LOWER(advertiser_domain) IN UNNEST(@domains)
        AND month >= DATE_SUB(CURRENT_DATE(), INTERVAL 3 MONTH)
      GROUP BY 1, 2, 3, 4, 5, 6, 7
    )
    SELECT
      domain, channel, publisher,
      creative_id, creative_url, creative_mime_type, creative_first_seen,
      SUM(impressions) AS impressions,
      SUM(spend)       AS spend
    FROM deduped
    GROUP BY 1, 2, 3, 4, 5, 6, 7
    ORDER BY impressions DESC
  `;
  const [rows] = await bq.query({
    query,
    params: { domains: domains.map((d) => d.toLowerCase()) },
    types: { domains: ["STRING"] }
  });
  return buildCampaignData(rows);
}
async function supabaseTrainingMode(domains) {
  const sb = createSupabase(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  );
  const lowerDomains = domains.map((d) => d.toLowerCase());
  const { data: rows, error } = await sb.from("ccr_training_data").select("advertiser_domain, data_type, data").in("advertiser_domain", lowerDomains);
  if (error) throw new Error(`Supabase training query failed: ${error.message}`);
  if (!rows || rows.length === 0) return [];
  const byDomain = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (!byDomain.has(row.advertiser_domain)) byDomain.set(row.advertiser_domain, {});
    byDomain.get(row.advertiser_domain)[row.data_type] = row.data;
  }
  return Array.from(byDomain.entries()).map(([domain, types]) => {
    const s = types.summary || {};
    const imp = Number(s.impressions) || 0;
    const spend = Number(s.spend) || 0;
    const total = imp || 1;
    const channels = [];
    const displayImp = Number(s.display_impressions) || 0;
    const videoImp = Number(s.video_impressions) || 0;
    const socialImp = Number(s.social_impressions) || 0;
    const ctvImp = Number(s.ctv_impressions) || 0;
    if (displayImp) channels.push({ name: "Display", impressions: displayImp, spend: Math.round(spend * displayImp / total) });
    if (videoImp) channels.push({ name: "Video", impressions: videoImp, spend: Math.round(spend * videoImp / total) });
    if (socialImp) channels.push({ name: "Social", impressions: socialImp, spend: Math.round(spend * socialImp / total) });
    if (ctvImp) channels.push({ name: "CTV", impressions: ctvImp, spend: Math.round(spend * ctvImp / total) });
    channels.sort((a, b) => b.impressions - a.impressions);
    const pubs = Array.isArray(types.publishers) ? types.publishers : [];
    const crvs = Array.isArray(types.creatives) ? types.creatives : [];
    return {
      domain,
      totalImpressions: imp,
      totalSpend: spend,
      channels,
      publishers: pubs.map((r) => ({ domain: r.publisher_group || r.domain || "Unknown", impressions: Number(r.impressions) || 0, spend: Number(r.spend) || 0 })).sort((a, b) => b.impressions - a.impressions).slice(0, 10),
      creatives: crvs.map((r) => ({ id: String(r.creative_id || ""), url: r.creative_url_supplier || r.url || "", mimeType: r.creative_mime_type || "", channelName: "", firstSeen: r.creative_first_seen || "" })).slice(0, 20)
    };
  }).filter((d) => d.totalImpressions > 0);
}
async function trainingMode(domains) {
  const bq = createBqClient();
  const ds = bq.dataset(process.env.ADCLARITY_DATASET || "adclarity_competitor_analysis");
  const domainSet = new Set(domains.map((d) => d.toLowerCase()));
  const [summaryHits, publisherHits, creativeHits] = await Promise.all([
    scanTable(ds, "adv_summary", domainSet, 1),
    scanTable(ds, "adv_publisher_channel_method", domainSet, 15),
    scanTable(ds, "adv_creative", domainSet, 10)
  ]);
  return Array.from(domainSet).map((domain) => {
    const summary = summaryHits.get(domain)?.[0];
    const publishers = publisherHits.get(domain) || [];
    const creatives = creativeHits.get(domain) || [];
    const imp = Number(summary?.impressions) || 0;
    const spend = Number(summary?.spend) || 0;
    const channels = [];
    if (summary) {
      const total = imp || 1;
      const displayImp = Number(summary.display_impressions) || 0;
      const videoImp = Number(summary.video_impressions) || 0;
      const socialImp = Number(summary.social_impressions) || 0;
      const ctvImp = Number(summary.ctv_impressions) || 0;
      if (displayImp) channels.push({ name: "Display", impressions: displayImp, spend: Math.round(spend * displayImp / total) });
      if (videoImp) channels.push({ name: "Video", impressions: videoImp, spend: Math.round(spend * videoImp / total) });
      if (socialImp) channels.push({ name: "Social", impressions: socialImp, spend: Math.round(spend * socialImp / total) });
      if (ctvImp) channels.push({ name: "CTV", impressions: ctvImp, spend: Math.round(spend * ctvImp / total) });
    }
    channels.sort((a, b) => b.impressions - a.impressions);
    return {
      domain,
      totalImpressions: imp,
      totalSpend: spend,
      channels,
      publishers: publishers.map((r) => ({
        domain: r.publisher_group || "Unknown",
        impressions: Number(r.impressions) || 0,
        spend: Number(r.spend) || 0
      })).sort((a, b) => b.impressions - a.impressions).slice(0, 10),
      creatives: creatives.map((r) => ({
        id: String(r.creative_id || r.creative_rank || ""),
        url: r.creative_url_supplier || "",
        mimeType: "",
        channelName: "",
        firstSeen: r.creative_first_seen ? String(r.creative_first_seen) : ""
      })).slice(0, 20)
    };
  }).filter((d) => d.totalImpressions > 0);
}
async function scanTable(ds, tableName, targets, maxPerDomain) {
  const table = ds.table(tableName);
  const found = /* @__PURE__ */ new Map();
  let token;
  let allFound = false;
  while (!allFound) {
    const opts = { maxResults: 1e4, autoPaginate: false };
    if (token) opts.pageToken = token;
    const [rows, nextQuery] = await table.getRows(opts);
    for (const r of rows) {
      const d = (r.advertiser_domain || "").toLowerCase();
      if (!targets.has(d)) continue;
      if (!found.has(d)) found.set(d, []);
      const arr = found.get(d);
      if (arr.length < maxPerDomain) arr.push(r);
    }
    token = nextQuery?.pageToken;
    if (!token) break;
    if (found.size >= targets.size) {
      allFound = [...targets].every((d) => (found.get(d)?.length || 0) >= maxPerDomain);
    }
  }
  return found;
}
function buildCampaignData(rows) {
  const byDomain = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const key = row.domain ?? "";
    if (!byDomain.has(key)) byDomain.set(key, []);
    byDomain.get(key).push(row);
  }
  return Array.from(byDomain.entries()).map(([domain, domainRows]) => {
    const channelMap = /* @__PURE__ */ new Map();
    const publisherMap = /* @__PURE__ */ new Map();
    const creativeMap = /* @__PURE__ */ new Map();
    let totalImpressions = 0;
    let totalSpend = 0;
    for (const row of domainRows) {
      const imp = Number(row.impressions) || 0;
      const spd = Number(row.spend) || 0;
      const ch = row.channel || "Unknown";
      const pub = row.publisher || "Unknown";
      const existingCh = channelMap.get(ch) ?? { impressions: 0, spend: 0 };
      channelMap.set(ch, { impressions: existingCh.impressions + imp, spend: existingCh.spend + spd });
      const existingPub = publisherMap.get(pub) ?? { impressions: 0, spend: 0 };
      publisherMap.set(pub, { impressions: existingPub.impressions + imp, spend: existingPub.spend + spd });
      if (row.creative_id && !creativeMap.has(row.creative_id)) {
        creativeMap.set(row.creative_id, {
          url: row.creative_url || "",
          mimeType: row.creative_mime_type || "",
          channelName: ch,
          firstSeen: row.creative_first_seen || ""
        });
      }
      totalImpressions += imp;
      totalSpend += spd;
    }
    return {
      domain,
      totalImpressions,
      totalSpend,
      channels: Array.from(channelMap.entries()).map(([name, d]) => ({ name, impressions: d.impressions, spend: d.spend })).sort((a, b) => b.impressions - a.impressions),
      publishers: Array.from(publisherMap.entries()).map(([pub, d]) => ({ domain: pub, impressions: d.impressions, spend: d.spend })).sort((a, b) => b.impressions - a.impressions).slice(0, 10),
      creatives: Array.from(creativeMap.entries()).map(([id, d]) => ({ id, url: d.url, mimeType: d.mimeType, channelName: d.channelName, firstSeen: d.firstSeen })).slice(0, 20)
    };
  });
}

// netlify/functions/_shared/firecrawl.ts
var FIRECRAWL_BASE = "https://api.firecrawl.dev/v1";
async function scrapeUrl(url) {
  const apiKey = process.env.FIRECRAWL_API_KEY;
  if (!apiKey) {
    console.warn("FIRECRAWL_API_KEY not configured \u2014 skipping scrape");
    return null;
  }
  const target = url.startsWith("http") ? url : `https://${url}`;
  try {
    const res = await fetch(`${FIRECRAWL_BASE}/scrape`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        url: target,
        formats: ["markdown", "screenshot"],
        timeout: 15e3,
        waitFor: 1e3,
        // Limit markdown to 5k chars — we only need industry context
        maxLength: 5e3
      })
    });
    if (!res.ok) {
      console.warn(`Firecrawl scrape failed for ${url}: ${res.status}`);
      return null;
    }
    const json = await res.json();
    if (!json.success) {
      console.warn(`Firecrawl returned !success for ${url}:`, json.error);
      return null;
    }
    const data = json.data ?? {};
    return {
      markdown: data.markdown || "",
      screenshotUrl: data.screenshot || null,
      title: data.metadata?.title || null,
      description: data.metadata?.description || null
    };
  } catch (err) {
    console.warn(`Firecrawl exception for ${url}:`, err);
    return null;
  }
}

// netlify/functions/_shared/logger.ts
import { createLogger } from "@AiDigital-com/design-system/logger";

// netlify/functions/_shared/supabase.ts
import { createClient } from "@supabase/supabase-js";
var supabaseUrl = process.env.SUPABASE_URL || "https://njwzbptrhgznozpndcxf.supabase.co";
var supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function getSupabase() {
  if (!supabaseKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY not configured");
  return createClient(supabaseUrl, supabaseKey);
}
var supabase = new Proxy({}, {
  get(_, prop) {
    return getSupabase()[prop];
  }
});

// netlify/functions/_shared/logger.ts
var log = createLogger(supabase, "competitor-campaign-review");

// netlify/functions/ccr-pipeline-background.mts
var APP_NAME = "competitor-campaign-review";
var ccr_pipeline_background_default = async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const body = await req.json();
  const { sessionId, jobId, intakeData, userId, userEmail } = body;
  if (!jobId || !sessionId || !intakeData?.brand_domain) {
    return new Response("Missing required fields", { status: 400 });
  }
  const { brand_domain } = intakeData;
  const supabase2 = createClient2(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
  const startTime = Date.now();
  await supabase2.from("job_status").upsert({
    id: jobId,
    app: APP_NAME,
    status: "streaming",
    meta: { current_step: "Discovering competitors\u2026" },
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  }, { onConflict: "id" });
  const setStep = async (step) => {
    await supabase2.from("job_status").update({
      meta: { current_step: step },
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", jobId);
  };
  try {
    log.info("ccr-pipeline.start", {
      function_name: "ccr-pipeline-background",
      user_id: userId,
      user_email: userEmail,
      entity_type: "session",
      entity_id: sessionId,
      correlation_id: jobId,
      meta: { brand_domain }
    });
    await setStep("Discovering competitors\u2026");
    let competitorDomains = [];
    try {
      competitorDomains = await getCompetitorDomains(brand_domain);
    } catch (err) {
      console.warn("DataForSeo failed, continuing without search competitors:", err);
    }
    await setStep("Fetching ad intelligence\u2026");
    const allDomains = [brand_domain, ...competitorDomains].slice(0, 11);
    let adData = [];
    if (process.env.GCP_PROJECT_ID && process.env.GOOGLE_CREDENTIALS) {
      try {
        adData = await getAdClarityData(allDomains);
      } catch (err) {
        console.warn("BigQuery failed:", err);
      }
    } else {
      console.warn("GCP env vars not configured \u2014 skipping AdClarity queries");
    }
    const adDataByDomain = new Map(adData.map((d) => [d.domain, d]));
    await setStep("Capturing screenshots\u2026");
    const domainsToScrape = [brand_domain, ...competitorDomains.slice(0, 5)];
    const scrapeResults = await Promise.allSettled(
      domainsToScrape.map((d) => scrapeUrl(d))
    );
    const mergedData = /* @__PURE__ */ new Map();
    domainsToScrape.forEach((domain, idx) => {
      const existing = adDataByDomain.get(domain.toLowerCase()) ?? {
        domain: domain.toLowerCase(),
        totalImpressions: 0,
        totalSpend: 0,
        channels: [],
        publishers: [],
        creatives: []
      };
      const scrape = scrapeResults[idx].status === "fulfilled" ? scrapeResults[idx].value : null;
      mergedData.set(domain.toLowerCase(), {
        ...existing,
        screenshotUrl: scrape?.screenshotUrl ?? null,
        scrapedTitle: scrape?.title ?? null,
        scrapedDescription: scrape?.description ?? null
      });
    });
    for (const [d, data] of adDataByDomain) {
      if (!mergedData.has(d)) mergedData.set(d, data);
    }
    const brandKey = brand_domain.toLowerCase();
    const brandData = mergedData.get(brandKey) ?? {
      domain: brandKey,
      totalImpressions: 0,
      totalSpend: 0,
      channels: [],
      publishers: [],
      creatives: []
    };
    const competitorsData = Array.from(mergedData.values()).filter((d) => d.domain !== brandKey).sort((a, b) => b.totalImpressions - a.totalImpressions).slice(0, 5);
    await setStep("Generating strategic analysis\u2026");
    const narrativeContext = buildNarrativeContext(brand_domain, brandData, competitorsData);
    const llm = createLLMProvider("gemini", process.env.GEMINI_API_KEY, "analysis", { supabase: supabase2 });
    const narrativeResult = await llm.generateContent({
      system: `You are a competitive intelligence analyst specializing in digital advertising strategy.
Write concise, actionable insights for marketing professionals.
Format with markdown headers (##) and bullet points. Max 600 words.`,
      prompt: narrativeContext,
      app: `${APP_NAME}:narrative`,
      userId: userId ?? void 0,
      maxTokens: 1024
    });
    log.info("ccr-pipeline.narrative", {
      function_name: "ccr-pipeline-background",
      user_id: userId,
      ai_provider: llm.provider,
      ai_model: llm.model,
      ai_input_tokens: narrativeResult.usage.inputTokens,
      ai_output_tokens: narrativeResult.usage.outputTokens,
      ai_total_tokens: narrativeResult.usage.totalTokens
    });
    const reportData = {
      brand: brandData,
      competitors: competitorsData,
      narrative: narrativeResult.text,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const reportJson = JSON.stringify(reportData);
    await supabase2.from("job_status").update({
      status: "complete",
      report: reportJson,
      meta: { current_step: "Complete" },
      completed_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", jobId);
    await supabase2.from("ccr_sessions").update({
      status: "complete",
      report_data: reportData,
      job_id: jobId,
      brand_name: brand_domain
    }).eq("id", sessionId);
    log.info("ccr-pipeline.complete", {
      function_name: "ccr-pipeline-background",
      user_id: userId,
      user_email: userEmail,
      entity_type: "session",
      entity_id: sessionId,
      correlation_id: jobId,
      duration_ms: Date.now() - startTime,
      ai_provider: llm.provider,
      ai_model: llm.model
    });
  } catch (err) {
    console.error("CCR pipeline error:", err);
    log.error("ccr-pipeline.error", {
      function_name: "ccr-pipeline-background",
      user_id: userId,
      user_email: userEmail,
      entity_type: "session",
      entity_id: sessionId,
      correlation_id: jobId,
      error: err,
      duration_ms: Date.now() - startTime
    });
    await supabase2.from("job_status").update({
      status: "error",
      error: err instanceof Error ? err.message : String(err),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", jobId);
    await supabase2.from("ccr_sessions").update({
      status: "error"
    }).eq("id", sessionId);
  }
};
var config = { background: true };
function fmtM(n) {
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(0)}K`;
  return String(n);
}
function buildNarrativeContext(brand, brandData, competitors) {
  const brandChannels = brandData.channels.map((c) => `${c.name}: ${fmtM(c.impressions)} imps`).join(", ") || "No channel data";
  const competitorSummaries = competitors.map(
    (c) => `${c.domain}: ${fmtM(c.totalImpressions)} imps, $${fmtM(c.totalSpend)} spend \u2014 channels: ${c.channels.map((ch) => ch.name).join(", ") || "none"}`
  ).join("\n");
  return `Analyze the competitive advertising landscape for "${brand}" and provide strategic recommendations.

BRAND: ${brand}
- Total Impressions: ${fmtM(brandData.totalImpressions)}
- Estimated Spend: $${fmtM(brandData.totalSpend)}
- Active Channels: ${brandChannels}
- Active Publishers: ${brandData.publishers.slice(0, 5).map((p) => p.domain).join(", ") || "None found"}

TOP COMPETITORS:
${competitorSummaries || "No competitor ad data found in AdClarity dataset."}

Provide a strategic analysis covering:
1. Share of voice assessment
2. Channel strategy gaps
3. Publisher opportunities competitors are exploiting
4. Creative and messaging recommendations
5. Budget prioritization suggestions

Be specific and actionable. Reference the actual data above.`;
}
export {
  config,
  ccr_pipeline_background_default as default
};
