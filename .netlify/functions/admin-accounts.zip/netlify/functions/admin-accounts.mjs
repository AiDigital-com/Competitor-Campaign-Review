
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.ts
import { verifyToken, createClerkClient } from "@clerk/backend";
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/_shared/supabase.ts
import { createClient } from "@supabase/supabase-js";
var supabaseUrl = process.env.SUPABASE_URL || "https://njwzbptrhgznozpndcxf.supabase.co";
var supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function getSupabase() {
  if (!supabaseKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY not configured");
  return createClient(supabaseUrl, supabaseKey);
}
var supabase = new Proxy({}, {
  get(_, prop) {
    return getSupabase()[prop];
  }
});
async function getUserStatus(userId) {
  const sb = getSupabase();
  const { data } = await sb.from("app_users").select("*").eq("user_id", userId).maybeSingle();
  return data ?? null;
}

// netlify/functions/_shared/logger.ts
import { createLogger } from "@AiDigital-com/design-system/logger";
var log = createLogger(supabase, "competitor-campaign-review");

// netlify/functions/_shared/auth.ts
async function requireAuth(req) {
  const secretKey = process.env.CLERK_SECRET_KEY;
  if (!secretKey) throw new Error("CLERK_SECRET_KEY not configured");
  const authHeader = req.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "").trim();
  if (!token) {
    log.warn("auth.failure", { function_name: "auth", message: "Unauthorized", meta: { endpoint: req.url } });
    throw new Error("Unauthorized");
  }
  const payload = await verifyToken(token, { secretKey });
  const userId = payload.sub;
  let email = null;
  try {
    const clerk = createClerkClient({ secretKey });
    const user = await clerk.users.getUser(userId);
    const primary = user.emailAddresses.find((e) => e.id === user.primaryEmailAddressId);
    email = primary?.emailAddress ?? null;
  } catch {
  }
  return { userId, email };
}
async function isAdminUser(userId) {
  const row = await getUserStatus(userId);
  if (row?.status === "admin") return true;
  const adminEmails = (process.env.ADMIN_EMAILS ?? "").split(",").map((e) => e.trim().toLowerCase()).filter(Boolean);
  const userEmail = row?.user_email?.toLowerCase();
  return userEmail ? adminEmails.includes(userEmail) : false;
}

// netlify/functions/admin-accounts.mts
var admin_accounts_default = async (req, _context) => {
  try {
    const { userId } = await requireAuth(req);
    const admin = await isAdminUser(userId);
    if (!admin) {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }
    const url = new URL(req.url);
    return Response.json({ accounts: [] });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
};
export {
  admin_accounts_default as default
};
