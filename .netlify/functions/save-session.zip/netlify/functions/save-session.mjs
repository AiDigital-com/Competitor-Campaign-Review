
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/save-session.mts
import { createClient } from "@supabase/supabase-js";
import { mergeSession } from "@AiDigital-com/design-system/server";
var SESSION_TABLE = "ccr_sessions";
var save_session_default = async (req, _context) => {
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { sessionId, patch, mergeConfig } = await req.json();
  if (!sessionId) {
    return Response.json({ error: "Missing sessionId" }, { status: 400 });
  }
  const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  );
  let result = await mergeSession(supabase, {
    table: SESSION_TABLE,
    sessionId,
    patch,
    mergeConfig: mergeConfig || { objectFields: ["intake_summary"] }
  });
  if (!result.ok && (result.error?.includes("not found") || result.error?.includes("Cannot coerce") || result.error?.includes("0 rows"))) {
    const { error: insertError } = await supabase.from(SESSION_TABLE).insert({ id: sessionId, ...patch }).select("id").single();
    if (insertError) {
      result = await mergeSession(supabase, {
        table: SESSION_TABLE,
        sessionId,
        patch,
        mergeConfig: mergeConfig || { objectFields: ["intake_summary"] }
      });
    } else {
      result = { ok: true };
    }
  }
  if (!result.ok) {
    return Response.json({ error: result.error }, { status: 500 });
  }
  return Response.json(result);
};
export {
  save_session_default as default
};
